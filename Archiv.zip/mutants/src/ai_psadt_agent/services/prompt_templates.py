"""Prompt templates for PSADT script generation with RAG integration."""

from typing import Dict, List, Optional
from dataclasses import dataclass

from .knowledge_base import SearchResult
from inspect import signature as _mutmut_signature
from typing import Annotated
from typing import Callable
from typing import ClassVar


MutantDict = Annotated[dict[str, Callable], "Mutant"]


def _mutmut_trampoline(orig, mutants, call_args, call_kwargs, self_arg = None):
    """Forward call to original or mutated function, depending on the environment"""
    import os
    mutant_under_test = os.environ['MUTANT_UNDER_TEST']
    if mutant_under_test == 'fail':
        from mutmut.__main__ import MutmutProgrammaticFailException
        raise MutmutProgrammaticFailException('Failed programmatically')      
    elif mutant_under_test == 'stats':
        from mutmut.__main__ import record_trampoline_hit
        record_trampoline_hit(orig.__module__ + '.' + orig.__name__)
        result = orig(*call_args, **call_kwargs)
        return result  # for the yield case
    prefix = orig.__module__ + '.' + orig.__name__ + '__mutmut_'
    if not mutant_under_test.startswith(prefix):
        result = orig(*call_args, **call_kwargs)
        return result  # for the yield case
    mutant_name = mutant_under_test.rpartition('.')[-1]
    if self_arg:
        # call to a class method where self is not bound
        result = mutants[mutant_name](self_arg, *call_args, **call_kwargs)
    else:
        result = mutants[mutant_name](*call_args, **call_kwargs)
    return result
from inspect import signature as _mutmut_signature
from typing import Annotated
from typing import Callable
from typing import ClassVar


MutantDict = Annotated[dict[str, Callable], "Mutant"]


def _mutmut_yield_from_trampoline(orig, mutants, call_args, call_kwargs, self_arg = None):
    """Forward call to original or mutated function, depending on the environment"""
    import os
    mutant_under_test = os.environ['MUTANT_UNDER_TEST']
    if mutant_under_test == 'fail':
        from mutmut.__main__ import MutmutProgrammaticFailException
        raise MutmutProgrammaticFailException('Failed programmatically')      
    elif mutant_under_test == 'stats':
        from mutmut.__main__ import record_trampoline_hit
        record_trampoline_hit(orig.__module__ + '.' + orig.__name__)
        result = yield from orig(*call_args, **call_kwargs)
        return result  # for the yield case
    prefix = orig.__module__ + '.' + orig.__name__ + '__mutmut_'
    if not mutant_under_test.startswith(prefix):
        result = yield from orig(*call_args, **call_kwargs)
        return result  # for the yield case
    mutant_name = mutant_under_test.rpartition('.')[-1]
    if self_arg:
        # call to a class method where self is not bound
        result = yield from mutants[mutant_name](self_arg, *call_args, **call_kwargs)
    else:
        result = yield from mutants[mutant_name](*call_args, **call_kwargs)
    return result


@dataclass
class InstallerMetadata:
    """Metadata about the installer."""

    name: str
    version: str
    vendor: str
    installer_type: str  # "msi", "exe", "msp", etc.
    installer_path: Optional[str] = None
    silent_args: Optional[str] = None
    uninstall_args: Optional[str] = None
    architecture: str = "x64"
    language: str = "EN"
    notes: Optional[str] = None


class PromptBuilder:
    """Builder for PSADT script generation prompts."""

    def xǁPromptBuilderǁ__init____mutmut_orig(self):
        """Initialize the prompt builder."""
        self.system_prompt = self._get_system_prompt()

    def xǁPromptBuilderǁ__init____mutmut_1(self):
        """Initialize the prompt builder."""
        self.system_prompt = None
    
    xǁPromptBuilderǁ__init____mutmut_mutants : ClassVar[MutantDict] = {
    'xǁPromptBuilderǁ__init____mutmut_1': xǁPromptBuilderǁ__init____mutmut_1
    }
    
    def __init__(self, *args, **kwargs):
        result = _mutmut_trampoline(object.__getattribute__(self, "xǁPromptBuilderǁ__init____mutmut_orig"), object.__getattribute__(self, "xǁPromptBuilderǁ__init____mutmut_mutants"), args, kwargs, self)
        return result 
    
    __init__.__signature__ = _mutmut_signature(xǁPromptBuilderǁ__init____mutmut_orig)
    xǁPromptBuilderǁ__init____mutmut_orig.__name__ = 'xǁPromptBuilderǁ__init__'

    def _get_system_prompt(self) -> str:
        """Get the system prompt for PSADT script generation."""
        return """You are an expert PowerShell App Deployment Toolkit (PSADT) script generator. 
Your task is to create production-ready PSADT v3.9+ deployment scripts based on installer metadata and user requirements.

Key Requirements:
1. Generate complete, functional PSADT scripts following v3.9+ standards
2. Use proper error handling with Try-Catch blocks
3. Include appropriate logging with Write-Log
4. Handle Install/Uninstall/Repair deployment types
5. Use Show-InstallationWelcome and Show-InstallationProgress for user experience
6. Follow PSADT best practices for enterprise deployment
7. Include proper variable declarations and metadata
8. Use Execute-MSI for MSI files, Execute-Process for EXE files
9. Handle application closure gracefully
10. Ensure clean exit with Exit-Script

Always provide complete, working scripts that can be deployed immediately in enterprise environments."""

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_orig(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_1(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = None

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_2(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"XXroleXX": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_3(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"ROLE": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_4(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"Role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_5(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "XXsystemXX", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_6(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "SYSTEM", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_7(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "System", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_8(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "XXcontentXX": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_9(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "CONTENT": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_10(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "Content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_11(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = None
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_12(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            None, user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_13(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, None, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_14(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, None
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_15(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            user_notes, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_16(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, rag_context
        )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_17(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, )
        messages.append({"role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_18(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append(None)

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_19(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"XXroleXX": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_20(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"ROLE": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_21(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"Role": "user", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_22(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "XXuserXX", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_23(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "USER", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_24(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "User", "content": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_25(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "XXcontentXX": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_26(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "CONTENT": user_prompt})

        return messages

    def xǁPromptBuilderǁbuild_generation_prompt__mutmut_27(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> List[Dict[str, str]]:
        """Build the complete prompt for script generation.

        Args:
            installer_metadata: Metadata about the installer
            user_notes: Additional user requirements or notes
            rag_context: RAG search results for context

        Returns:
            List of messages for LLM
        """
        messages = [{"role": "system", "content": self.system_prompt}]

        # Build user prompt with installer metadata
        user_prompt = self._build_user_prompt(
            installer_metadata, user_notes, rag_context
        )
        messages.append({"role": "user", "Content": user_prompt})

        return messages
    
    xǁPromptBuilderǁbuild_generation_prompt__mutmut_mutants : ClassVar[MutantDict] = {
    'xǁPromptBuilderǁbuild_generation_prompt__mutmut_1': xǁPromptBuilderǁbuild_generation_prompt__mutmut_1, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_2': xǁPromptBuilderǁbuild_generation_prompt__mutmut_2, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_3': xǁPromptBuilderǁbuild_generation_prompt__mutmut_3, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_4': xǁPromptBuilderǁbuild_generation_prompt__mutmut_4, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_5': xǁPromptBuilderǁbuild_generation_prompt__mutmut_5, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_6': xǁPromptBuilderǁbuild_generation_prompt__mutmut_6, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_7': xǁPromptBuilderǁbuild_generation_prompt__mutmut_7, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_8': xǁPromptBuilderǁbuild_generation_prompt__mutmut_8, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_9': xǁPromptBuilderǁbuild_generation_prompt__mutmut_9, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_10': xǁPromptBuilderǁbuild_generation_prompt__mutmut_10, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_11': xǁPromptBuilderǁbuild_generation_prompt__mutmut_11, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_12': xǁPromptBuilderǁbuild_generation_prompt__mutmut_12, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_13': xǁPromptBuilderǁbuild_generation_prompt__mutmut_13, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_14': xǁPromptBuilderǁbuild_generation_prompt__mutmut_14, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_15': xǁPromptBuilderǁbuild_generation_prompt__mutmut_15, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_16': xǁPromptBuilderǁbuild_generation_prompt__mutmut_16, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_17': xǁPromptBuilderǁbuild_generation_prompt__mutmut_17, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_18': xǁPromptBuilderǁbuild_generation_prompt__mutmut_18, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_19': xǁPromptBuilderǁbuild_generation_prompt__mutmut_19, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_20': xǁPromptBuilderǁbuild_generation_prompt__mutmut_20, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_21': xǁPromptBuilderǁbuild_generation_prompt__mutmut_21, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_22': xǁPromptBuilderǁbuild_generation_prompt__mutmut_22, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_23': xǁPromptBuilderǁbuild_generation_prompt__mutmut_23, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_24': xǁPromptBuilderǁbuild_generation_prompt__mutmut_24, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_25': xǁPromptBuilderǁbuild_generation_prompt__mutmut_25, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_26': xǁPromptBuilderǁbuild_generation_prompt__mutmut_26, 
        'xǁPromptBuilderǁbuild_generation_prompt__mutmut_27': xǁPromptBuilderǁbuild_generation_prompt__mutmut_27
    }
    
    def build_generation_prompt(self, *args, **kwargs):
        result = _mutmut_trampoline(object.__getattribute__(self, "xǁPromptBuilderǁbuild_generation_prompt__mutmut_orig"), object.__getattribute__(self, "xǁPromptBuilderǁbuild_generation_prompt__mutmut_mutants"), args, kwargs, self)
        return result 
    
    build_generation_prompt.__signature__ = _mutmut_signature(xǁPromptBuilderǁbuild_generation_prompt__mutmut_orig)
    xǁPromptBuilderǁbuild_generation_prompt__mutmut_orig.__name__ = 'xǁPromptBuilderǁbuild_generation_prompt'

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_orig(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_1(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = None

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_2(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append(None)
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_3(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("XX## Installer InformationXX")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_4(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## installer information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_5(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## INSTALLER INFORMATION")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_6(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## installer information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_7(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(None)
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_8(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(None)
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_9(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(None)
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_10(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            None
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_11(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.lower()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_12(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(None)
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_13(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(None)

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_14(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(None)

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_15(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                None
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_16(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                None
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_17(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(None)

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_18(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes or user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_19(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append(None)
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_20(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("XX\n## Additional RequirementsXX")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_21(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## additional requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_22(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\N## ADDITIONAL REQUIREMENTS")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_23(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## additional requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_24(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(None)

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_25(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append(None)
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_26(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("XX\n## PSADT Documentation ContextXX")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_27(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## psadt documentation context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_28(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\N## PSADT DOCUMENTATION CONTEXT")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_29(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## psadt documentation context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_30(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                None
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_31(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "XXThe following documentation excerpts are relevant to your task:XX"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_32(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "the following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_33(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "THE FOLLOWING DOCUMENTATION EXCERPTS ARE RELEVANT TO YOUR TASK:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_34(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(None, 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_35(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], None):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_36(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_37(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], ):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_38(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:9], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_39(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 2):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_40(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(None)
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_41(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    None
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_42(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get(None, 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_43(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', None)}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_44(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_45(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', )}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_46(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('XXfilenameXX', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_47(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('FILENAME', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_48(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('Filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_49(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'XXUnknownXX')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_50(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_51(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'UNKNOWN')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_52(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = None
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_53(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) >= 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_54(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2001:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_55(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = None
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_56(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2001] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_57(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] - "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_58(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "XX...[truncated]XX"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_59(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[TRUNCATED]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_60(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(None)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_61(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append(None)
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_62(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("XX\n## TaskXX")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_63(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_64(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\N## TASK")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_65(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_66(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            None
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_67(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "XXGenerate a complete PSADT v3.9+ PowerShell script for this installer. XX"
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_68(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "generate a complete psadt v3.9+ powershell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_69(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "GENERATE A COMPLETE PSADT V3.9+ POWERSHELL SCRIPT FOR THIS INSTALLER. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_70(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete psadt v3.9+ powershell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_71(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "XXThe script should be production-ready and follow all PSADT best practices. XX"
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_72(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "the script should be production-ready and follow all psadt best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_73(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "THE SCRIPT SHOULD BE PRODUCTION-READY AND FOLLOW ALL PSADT BEST PRACTICES. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_74(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all psadt best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_75(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "XXInclude proper error handling, logging, user interaction, and support for XX"
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_76(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_77(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "INCLUDE PROPER ERROR HANDLING, LOGGING, USER INTERACTION, AND SUPPORT FOR "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_78(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "XXInstall/Uninstall/Repair operations.XX"
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_79(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "install/uninstall/repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_80(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "INSTALL/UNINSTALL/REPAIR OPERATIONS."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_81(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/uninstall/repair operations."
        )

        return "\n".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_82(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\n".join(None)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_83(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "XX\nXX".join(prompt_parts)

    def xǁPromptBuilderǁ_build_user_prompt__mutmut_84(
        self,
        installer_metadata: InstallerMetadata,
        user_notes: Optional[str] = None,
        rag_context: Optional[List[SearchResult]] = None,
    ) -> str:
        """Build the user prompt with metadata and context.

        Args:
            installer_metadata: Installer metadata
            user_notes: User notes/requirements
            rag_context: RAG search results

        Returns:
            Formatted user prompt
        """
        prompt_parts = []

        # Add installer metadata
        prompt_parts.append("## Installer Information")
        prompt_parts.append(f"Application Name: {installer_metadata.name}")
        prompt_parts.append(f"Version: {installer_metadata.version}")
        prompt_parts.append(f"Vendor: {installer_metadata.vendor}")
        prompt_parts.append(
            f"Installer Type: {installer_metadata.installer_type.upper()}"
        )
        prompt_parts.append(f"Architecture: {installer_metadata.architecture}")
        prompt_parts.append(f"Language: {installer_metadata.language}")

        if installer_metadata.installer_path:
            prompt_parts.append(f"Installer Path: {installer_metadata.installer_path}")

        if installer_metadata.silent_args:
            prompt_parts.append(
                f"Silent Install Arguments: {installer_metadata.silent_args}"
            )

        if installer_metadata.uninstall_args:
            prompt_parts.append(
                f"Uninstall Arguments: {installer_metadata.uninstall_args}"
            )

        if installer_metadata.notes:
            prompt_parts.append(f"Installer Notes: {installer_metadata.notes}")

        # Add user notes if provided
        if user_notes and user_notes.strip():
            prompt_parts.append("\n## Additional Requirements")
            prompt_parts.append(user_notes.strip())

        # Add RAG context if available
        if rag_context:
            prompt_parts.append("\n## PSADT Documentation Context")
            prompt_parts.append(
                "The following documentation excerpts are relevant to your task:"
            )

            for i, result in enumerate(rag_context[:8], 1):  # Limit to top 8 results
                prompt_parts.append(f"\n### Context {i} (Score: {result.score:.3f})")
                prompt_parts.append(
                    f"Source: {result.document.metadata.get('filename', 'Unknown')}"
                )
                # Truncate very long content
                content = result.document.content
                if len(content) > 2000:
                    content = content[:2000] + "...[truncated]"
                prompt_parts.append(content)

        # Add final instructions
        prompt_parts.append("\n## Task")
        prompt_parts.append(
            "Generate a complete PSADT v3.9+ PowerShell script for this installer. "
            "The script should be production-ready and follow all PSADT best practices. "
            "Include proper error handling, logging, user interaction, and support for "
            "Install/Uninstall/Repair operations."
        )

        return "\N".join(prompt_parts)
    
    xǁPromptBuilderǁ_build_user_prompt__mutmut_mutants : ClassVar[MutantDict] = {
    'xǁPromptBuilderǁ_build_user_prompt__mutmut_1': xǁPromptBuilderǁ_build_user_prompt__mutmut_1, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_2': xǁPromptBuilderǁ_build_user_prompt__mutmut_2, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_3': xǁPromptBuilderǁ_build_user_prompt__mutmut_3, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_4': xǁPromptBuilderǁ_build_user_prompt__mutmut_4, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_5': xǁPromptBuilderǁ_build_user_prompt__mutmut_5, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_6': xǁPromptBuilderǁ_build_user_prompt__mutmut_6, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_7': xǁPromptBuilderǁ_build_user_prompt__mutmut_7, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_8': xǁPromptBuilderǁ_build_user_prompt__mutmut_8, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_9': xǁPromptBuilderǁ_build_user_prompt__mutmut_9, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_10': xǁPromptBuilderǁ_build_user_prompt__mutmut_10, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_11': xǁPromptBuilderǁ_build_user_prompt__mutmut_11, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_12': xǁPromptBuilderǁ_build_user_prompt__mutmut_12, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_13': xǁPromptBuilderǁ_build_user_prompt__mutmut_13, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_14': xǁPromptBuilderǁ_build_user_prompt__mutmut_14, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_15': xǁPromptBuilderǁ_build_user_prompt__mutmut_15, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_16': xǁPromptBuilderǁ_build_user_prompt__mutmut_16, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_17': xǁPromptBuilderǁ_build_user_prompt__mutmut_17, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_18': xǁPromptBuilderǁ_build_user_prompt__mutmut_18, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_19': xǁPromptBuilderǁ_build_user_prompt__mutmut_19, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_20': xǁPromptBuilderǁ_build_user_prompt__mutmut_20, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_21': xǁPromptBuilderǁ_build_user_prompt__mutmut_21, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_22': xǁPromptBuilderǁ_build_user_prompt__mutmut_22, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_23': xǁPromptBuilderǁ_build_user_prompt__mutmut_23, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_24': xǁPromptBuilderǁ_build_user_prompt__mutmut_24, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_25': xǁPromptBuilderǁ_build_user_prompt__mutmut_25, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_26': xǁPromptBuilderǁ_build_user_prompt__mutmut_26, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_27': xǁPromptBuilderǁ_build_user_prompt__mutmut_27, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_28': xǁPromptBuilderǁ_build_user_prompt__mutmut_28, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_29': xǁPromptBuilderǁ_build_user_prompt__mutmut_29, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_30': xǁPromptBuilderǁ_build_user_prompt__mutmut_30, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_31': xǁPromptBuilderǁ_build_user_prompt__mutmut_31, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_32': xǁPromptBuilderǁ_build_user_prompt__mutmut_32, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_33': xǁPromptBuilderǁ_build_user_prompt__mutmut_33, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_34': xǁPromptBuilderǁ_build_user_prompt__mutmut_34, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_35': xǁPromptBuilderǁ_build_user_prompt__mutmut_35, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_36': xǁPromptBuilderǁ_build_user_prompt__mutmut_36, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_37': xǁPromptBuilderǁ_build_user_prompt__mutmut_37, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_38': xǁPromptBuilderǁ_build_user_prompt__mutmut_38, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_39': xǁPromptBuilderǁ_build_user_prompt__mutmut_39, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_40': xǁPromptBuilderǁ_build_user_prompt__mutmut_40, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_41': xǁPromptBuilderǁ_build_user_prompt__mutmut_41, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_42': xǁPromptBuilderǁ_build_user_prompt__mutmut_42, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_43': xǁPromptBuilderǁ_build_user_prompt__mutmut_43, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_44': xǁPromptBuilderǁ_build_user_prompt__mutmut_44, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_45': xǁPromptBuilderǁ_build_user_prompt__mutmut_45, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_46': xǁPromptBuilderǁ_build_user_prompt__mutmut_46, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_47': xǁPromptBuilderǁ_build_user_prompt__mutmut_47, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_48': xǁPromptBuilderǁ_build_user_prompt__mutmut_48, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_49': xǁPromptBuilderǁ_build_user_prompt__mutmut_49, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_50': xǁPromptBuilderǁ_build_user_prompt__mutmut_50, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_51': xǁPromptBuilderǁ_build_user_prompt__mutmut_51, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_52': xǁPromptBuilderǁ_build_user_prompt__mutmut_52, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_53': xǁPromptBuilderǁ_build_user_prompt__mutmut_53, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_54': xǁPromptBuilderǁ_build_user_prompt__mutmut_54, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_55': xǁPromptBuilderǁ_build_user_prompt__mutmut_55, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_56': xǁPromptBuilderǁ_build_user_prompt__mutmut_56, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_57': xǁPromptBuilderǁ_build_user_prompt__mutmut_57, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_58': xǁPromptBuilderǁ_build_user_prompt__mutmut_58, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_59': xǁPromptBuilderǁ_build_user_prompt__mutmut_59, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_60': xǁPromptBuilderǁ_build_user_prompt__mutmut_60, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_61': xǁPromptBuilderǁ_build_user_prompt__mutmut_61, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_62': xǁPromptBuilderǁ_build_user_prompt__mutmut_62, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_63': xǁPromptBuilderǁ_build_user_prompt__mutmut_63, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_64': xǁPromptBuilderǁ_build_user_prompt__mutmut_64, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_65': xǁPromptBuilderǁ_build_user_prompt__mutmut_65, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_66': xǁPromptBuilderǁ_build_user_prompt__mutmut_66, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_67': xǁPromptBuilderǁ_build_user_prompt__mutmut_67, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_68': xǁPromptBuilderǁ_build_user_prompt__mutmut_68, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_69': xǁPromptBuilderǁ_build_user_prompt__mutmut_69, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_70': xǁPromptBuilderǁ_build_user_prompt__mutmut_70, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_71': xǁPromptBuilderǁ_build_user_prompt__mutmut_71, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_72': xǁPromptBuilderǁ_build_user_prompt__mutmut_72, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_73': xǁPromptBuilderǁ_build_user_prompt__mutmut_73, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_74': xǁPromptBuilderǁ_build_user_prompt__mutmut_74, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_75': xǁPromptBuilderǁ_build_user_prompt__mutmut_75, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_76': xǁPromptBuilderǁ_build_user_prompt__mutmut_76, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_77': xǁPromptBuilderǁ_build_user_prompt__mutmut_77, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_78': xǁPromptBuilderǁ_build_user_prompt__mutmut_78, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_79': xǁPromptBuilderǁ_build_user_prompt__mutmut_79, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_80': xǁPromptBuilderǁ_build_user_prompt__mutmut_80, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_81': xǁPromptBuilderǁ_build_user_prompt__mutmut_81, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_82': xǁPromptBuilderǁ_build_user_prompt__mutmut_82, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_83': xǁPromptBuilderǁ_build_user_prompt__mutmut_83, 
        'xǁPromptBuilderǁ_build_user_prompt__mutmut_84': xǁPromptBuilderǁ_build_user_prompt__mutmut_84
    }
    
    def _build_user_prompt(self, *args, **kwargs):
        result = _mutmut_trampoline(object.__getattribute__(self, "xǁPromptBuilderǁ_build_user_prompt__mutmut_orig"), object.__getattribute__(self, "xǁPromptBuilderǁ_build_user_prompt__mutmut_mutants"), args, kwargs, self)
        return result 
    
    _build_user_prompt.__signature__ = _mutmut_signature(xǁPromptBuilderǁ_build_user_prompt__mutmut_orig)
    xǁPromptBuilderǁ_build_user_prompt__mutmut_orig.__name__ = 'xǁPromptBuilderǁ_build_user_prompt'

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_orig(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_1(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = None

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_2(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = None

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_3(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"XXroleXX": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_4(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"ROLE": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_5(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"Role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_6(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "XXsystemXX", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_7(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "SYSTEM", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_8(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "System", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_9(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "XXcontentXX": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_10(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "CONTENT": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_11(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "Content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_12(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"XXroleXX": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_13(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"ROLE": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_14(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"Role": "user", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_15(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "XXuserXX", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_16(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "USER", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_17(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "User", "content": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_18(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "XXcontentXX": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_19(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "CONTENT": user_prompt},
        ]

    def xǁPromptBuilderǁbuild_validation_prompt__mutmut_20(self, script_content: str) -> List[Dict[str, str]]:
        """Build prompt for script validation.

        Args:
            script_content: Generated PSADT script content

        Returns:
            List of messages for validation
        """
        system_prompt = """You are a PSADT script validator. Review the provided PowerShell script and identify any issues, improvements, or non-compliance with PSADT v3.9+ standards.

Check for:
1. Proper PSADT structure and required sections
2. Correct variable declarations
3. Appropriate error handling
4. Proper use of PSADT functions
5. Syntax correctness
6. Best practice compliance
7. Security considerations

Provide a JSON response with:
- "valid": boolean indicating if script is valid
- "issues": array of issue descriptions
- "suggestions": array of improvement suggestions
- "score": numeric score from 0-100"""

        user_prompt = f"""Please validate this PSADT script:

```powershell
{script_content}
```

Respond with a JSON object containing your validation results."""

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "Content": user_prompt},
        ]
    
    xǁPromptBuilderǁbuild_validation_prompt__mutmut_mutants : ClassVar[MutantDict] = {
    'xǁPromptBuilderǁbuild_validation_prompt__mutmut_1': xǁPromptBuilderǁbuild_validation_prompt__mutmut_1, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_2': xǁPromptBuilderǁbuild_validation_prompt__mutmut_2, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_3': xǁPromptBuilderǁbuild_validation_prompt__mutmut_3, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_4': xǁPromptBuilderǁbuild_validation_prompt__mutmut_4, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_5': xǁPromptBuilderǁbuild_validation_prompt__mutmut_5, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_6': xǁPromptBuilderǁbuild_validation_prompt__mutmut_6, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_7': xǁPromptBuilderǁbuild_validation_prompt__mutmut_7, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_8': xǁPromptBuilderǁbuild_validation_prompt__mutmut_8, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_9': xǁPromptBuilderǁbuild_validation_prompt__mutmut_9, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_10': xǁPromptBuilderǁbuild_validation_prompt__mutmut_10, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_11': xǁPromptBuilderǁbuild_validation_prompt__mutmut_11, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_12': xǁPromptBuilderǁbuild_validation_prompt__mutmut_12, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_13': xǁPromptBuilderǁbuild_validation_prompt__mutmut_13, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_14': xǁPromptBuilderǁbuild_validation_prompt__mutmut_14, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_15': xǁPromptBuilderǁbuild_validation_prompt__mutmut_15, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_16': xǁPromptBuilderǁbuild_validation_prompt__mutmut_16, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_17': xǁPromptBuilderǁbuild_validation_prompt__mutmut_17, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_18': xǁPromptBuilderǁbuild_validation_prompt__mutmut_18, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_19': xǁPromptBuilderǁbuild_validation_prompt__mutmut_19, 
        'xǁPromptBuilderǁbuild_validation_prompt__mutmut_20': xǁPromptBuilderǁbuild_validation_prompt__mutmut_20
    }
    
    def build_validation_prompt(self, *args, **kwargs):
        result = _mutmut_trampoline(object.__getattribute__(self, "xǁPromptBuilderǁbuild_validation_prompt__mutmut_orig"), object.__getattribute__(self, "xǁPromptBuilderǁbuild_validation_prompt__mutmut_mutants"), args, kwargs, self)
        return result 
    
    build_validation_prompt.__signature__ = _mutmut_signature(xǁPromptBuilderǁbuild_validation_prompt__mutmut_orig)
    xǁPromptBuilderǁbuild_validation_prompt__mutmut_orig.__name__ = 'xǁPromptBuilderǁbuild_validation_prompt'


def x_build_rag_query__mutmut_orig(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_1(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = None

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_2(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.upper() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_3(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() != "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_4(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "XXmsiXX":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_5(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "MSI":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_6(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "Msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_7(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(None)
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_8(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["XXMSIXX", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_9(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["msi", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_10(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["Msi", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_11(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "XXExecute-MSIXX", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_12(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "execute-msi", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_13(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "EXECUTE-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_14(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-msi", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_15(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "XXWindows InstallerXX"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_16(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "windows installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_17(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "WINDOWS INSTALLER"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_18(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_19(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.upper() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_20(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() != "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_21(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "XXexeXX":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_22(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "EXE":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_23(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "Exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_24(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(None)

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_25(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["XXEXEXX", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_26(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["exe", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_27(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["Exe", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_28(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "XXExecute-ProcessXX", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_29(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "execute-process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_30(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "EXECUTE-PROCESS", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_31(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_32(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "XXexecutableXX"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_33(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "EXECUTABLE"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_34(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "Executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_35(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = None
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_36(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.upper()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_37(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        None
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_38(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term not in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_39(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["XXofficeXX", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_40(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["OFFICE", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_41(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["Office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_42(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "XXwordXX", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_43(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "WORD", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_44(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "Word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_45(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "XXexcelXX", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_46(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "EXCEL", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_47(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "Excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_48(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "XXpowerpointXX"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_49(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "POWERPOINT"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_50(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "Powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_51(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append(None)
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_52(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("XXMicrosoft OfficeXX")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_53(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("microsoft office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_54(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("MICROSOFT OFFICE")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_55(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_56(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(None):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_57(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term not in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_58(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["XXchromeXX", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_59(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["CHROME", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_60(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["Chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_61(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "XXfirefoxXX", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_62(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "FIREFOX", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_63(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "Firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_64(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "XXbrowserXX"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_65(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "BROWSER"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_66(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "Browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_67(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append(None)
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_68(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("XXweb browserXX")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_69(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("WEB BROWSER")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_70(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("Web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_71(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(None):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_72(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term not in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_73(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["XXjavaXX", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_74(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["JAVA", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_75(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["Java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_76(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "XXjreXX", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_77(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "JRE", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_78(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "Jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_79(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "XXjdkXX"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_80(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "JDK"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_81(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "Jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_82(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append(None)
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_83(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("XXJava runtimeXX")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_84(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_85(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("JAVA RUNTIME")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_86(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(None):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_87(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term not in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_88(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["XXadobeXX", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_89(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["ADOBE", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_90(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["Adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_91(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "XXacrobatXX", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_92(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "ACROBAT", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_93(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "Acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_94(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "XXreaderXX"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_95(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "READER"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_96(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "Reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_97(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append(None)

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_98(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("XXAdobeXX")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_99(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_100(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("ADOBE")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_101(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = None
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_102(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.upper()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_103(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "XXsilentXX" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_104(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "SILENT" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_105(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "Silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_106(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" not in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_107(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append(None)
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_108(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("XXsilent installationXX")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_109(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("SILENT INSTALLATION")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_110(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("Silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_111(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "XXregistryXX" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_112(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "REGISTRY" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_113(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "Registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_114(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" not in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_115(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append(None)
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_116(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("XXregistry modificationXX")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_117(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("REGISTRY MODIFICATION")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_118(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("Registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_119(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "XXserviceXX" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_120(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "SERVICE" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_121(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "Service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_122(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" not in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_123(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append(None)
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_124(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("XXWindows serviceXX")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_125(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_126(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("WINDOWS SERVICE")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_127(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "XXshortcutXX" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_128(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "SHORTCUT" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_129(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "Shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_130(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" not in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_131(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append(None)

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_132(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("XXdesktop shortcutXX")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_133(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("DESKTOP SHORTCUT")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_134(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("Desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_135(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(None)

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_136(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["XXPSADTXX", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_137(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["psadt", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_138(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["Psadt", "deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_139(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "XXdeploymentXX", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_140(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "DEPLOYMENT", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_141(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "Deployment", "installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_142(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "XXinstallationXX"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_143(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "INSTALLATION"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_144(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "Installation"])

    # Join and return
    return " ".join(query_parts)


def x_build_rag_query__mutmut_145(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return " ".join(None)


def x_build_rag_query__mutmut_146(
    installer_metadata: InstallerMetadata, user_notes: Optional[str] = None
) -> str:
    """Build search query for RAG knowledge base lookup.

    Args:
        installer_metadata: Installer metadata
        user_notes: User notes

    Returns:
        Search query string
    """
    query_parts = []

    # Add installer type specific terms
    if installer_metadata.installer_type.lower() == "msi":
        query_parts.extend(["MSI", "Execute-MSI", "Windows Installer"])
    elif installer_metadata.installer_type.lower() == "exe":
        query_parts.extend(["EXE", "Execute-Process", "executable"])

    # Add application type if extractable from name
    app_name_lower = installer_metadata.name.lower()
    if any(
        term in app_name_lower for term in ["office", "word", "excel", "powerpoint"]
    ):
        query_parts.append("Microsoft Office")
    elif any(term in app_name_lower for term in ["chrome", "firefox", "browser"]):
        query_parts.append("web browser")
    elif any(term in app_name_lower for term in ["java", "jre", "jdk"]):
        query_parts.append("Java runtime")
    elif any(term in app_name_lower for term in ["adobe", "acrobat", "reader"]):
        query_parts.append("Adobe")

    # Add user-specific terms from notes
    if user_notes:
        # Extract key terms from user notes
        notes_lower = user_notes.lower()
        if "silent" in notes_lower:
            query_parts.append("silent installation")
        if "registry" in notes_lower:
            query_parts.append("registry modification")
        if "service" in notes_lower:
            query_parts.append("Windows service")
        if "shortcut" in notes_lower:
            query_parts.append("desktop shortcut")

    # Add general PSADT terms
    query_parts.extend(["PSADT", "deployment", "installation"])

    # Join and return
    return "XX XX".join(query_parts)

x_build_rag_query__mutmut_mutants : ClassVar[MutantDict] = {
'x_build_rag_query__mutmut_1': x_build_rag_query__mutmut_1, 
    'x_build_rag_query__mutmut_2': x_build_rag_query__mutmut_2, 
    'x_build_rag_query__mutmut_3': x_build_rag_query__mutmut_3, 
    'x_build_rag_query__mutmut_4': x_build_rag_query__mutmut_4, 
    'x_build_rag_query__mutmut_5': x_build_rag_query__mutmut_5, 
    'x_build_rag_query__mutmut_6': x_build_rag_query__mutmut_6, 
    'x_build_rag_query__mutmut_7': x_build_rag_query__mutmut_7, 
    'x_build_rag_query__mutmut_8': x_build_rag_query__mutmut_8, 
    'x_build_rag_query__mutmut_9': x_build_rag_query__mutmut_9, 
    'x_build_rag_query__mutmut_10': x_build_rag_query__mutmut_10, 
    'x_build_rag_query__mutmut_11': x_build_rag_query__mutmut_11, 
    'x_build_rag_query__mutmut_12': x_build_rag_query__mutmut_12, 
    'x_build_rag_query__mutmut_13': x_build_rag_query__mutmut_13, 
    'x_build_rag_query__mutmut_14': x_build_rag_query__mutmut_14, 
    'x_build_rag_query__mutmut_15': x_build_rag_query__mutmut_15, 
    'x_build_rag_query__mutmut_16': x_build_rag_query__mutmut_16, 
    'x_build_rag_query__mutmut_17': x_build_rag_query__mutmut_17, 
    'x_build_rag_query__mutmut_18': x_build_rag_query__mutmut_18, 
    'x_build_rag_query__mutmut_19': x_build_rag_query__mutmut_19, 
    'x_build_rag_query__mutmut_20': x_build_rag_query__mutmut_20, 
    'x_build_rag_query__mutmut_21': x_build_rag_query__mutmut_21, 
    'x_build_rag_query__mutmut_22': x_build_rag_query__mutmut_22, 
    'x_build_rag_query__mutmut_23': x_build_rag_query__mutmut_23, 
    'x_build_rag_query__mutmut_24': x_build_rag_query__mutmut_24, 
    'x_build_rag_query__mutmut_25': x_build_rag_query__mutmut_25, 
    'x_build_rag_query__mutmut_26': x_build_rag_query__mutmut_26, 
    'x_build_rag_query__mutmut_27': x_build_rag_query__mutmut_27, 
    'x_build_rag_query__mutmut_28': x_build_rag_query__mutmut_28, 
    'x_build_rag_query__mutmut_29': x_build_rag_query__mutmut_29, 
    'x_build_rag_query__mutmut_30': x_build_rag_query__mutmut_30, 
    'x_build_rag_query__mutmut_31': x_build_rag_query__mutmut_31, 
    'x_build_rag_query__mutmut_32': x_build_rag_query__mutmut_32, 
    'x_build_rag_query__mutmut_33': x_build_rag_query__mutmut_33, 
    'x_build_rag_query__mutmut_34': x_build_rag_query__mutmut_34, 
    'x_build_rag_query__mutmut_35': x_build_rag_query__mutmut_35, 
    'x_build_rag_query__mutmut_36': x_build_rag_query__mutmut_36, 
    'x_build_rag_query__mutmut_37': x_build_rag_query__mutmut_37, 
    'x_build_rag_query__mutmut_38': x_build_rag_query__mutmut_38, 
    'x_build_rag_query__mutmut_39': x_build_rag_query__mutmut_39, 
    'x_build_rag_query__mutmut_40': x_build_rag_query__mutmut_40, 
    'x_build_rag_query__mutmut_41': x_build_rag_query__mutmut_41, 
    'x_build_rag_query__mutmut_42': x_build_rag_query__mutmut_42, 
    'x_build_rag_query__mutmut_43': x_build_rag_query__mutmut_43, 
    'x_build_rag_query__mutmut_44': x_build_rag_query__mutmut_44, 
    'x_build_rag_query__mutmut_45': x_build_rag_query__mutmut_45, 
    'x_build_rag_query__mutmut_46': x_build_rag_query__mutmut_46, 
    'x_build_rag_query__mutmut_47': x_build_rag_query__mutmut_47, 
    'x_build_rag_query__mutmut_48': x_build_rag_query__mutmut_48, 
    'x_build_rag_query__mutmut_49': x_build_rag_query__mutmut_49, 
    'x_build_rag_query__mutmut_50': x_build_rag_query__mutmut_50, 
    'x_build_rag_query__mutmut_51': x_build_rag_query__mutmut_51, 
    'x_build_rag_query__mutmut_52': x_build_rag_query__mutmut_52, 
    'x_build_rag_query__mutmut_53': x_build_rag_query__mutmut_53, 
    'x_build_rag_query__mutmut_54': x_build_rag_query__mutmut_54, 
    'x_build_rag_query__mutmut_55': x_build_rag_query__mutmut_55, 
    'x_build_rag_query__mutmut_56': x_build_rag_query__mutmut_56, 
    'x_build_rag_query__mutmut_57': x_build_rag_query__mutmut_57, 
    'x_build_rag_query__mutmut_58': x_build_rag_query__mutmut_58, 
    'x_build_rag_query__mutmut_59': x_build_rag_query__mutmut_59, 
    'x_build_rag_query__mutmut_60': x_build_rag_query__mutmut_60, 
    'x_build_rag_query__mutmut_61': x_build_rag_query__mutmut_61, 
    'x_build_rag_query__mutmut_62': x_build_rag_query__mutmut_62, 
    'x_build_rag_query__mutmut_63': x_build_rag_query__mutmut_63, 
    'x_build_rag_query__mutmut_64': x_build_rag_query__mutmut_64, 
    'x_build_rag_query__mutmut_65': x_build_rag_query__mutmut_65, 
    'x_build_rag_query__mutmut_66': x_build_rag_query__mutmut_66, 
    'x_build_rag_query__mutmut_67': x_build_rag_query__mutmut_67, 
    'x_build_rag_query__mutmut_68': x_build_rag_query__mutmut_68, 
    'x_build_rag_query__mutmut_69': x_build_rag_query__mutmut_69, 
    'x_build_rag_query__mutmut_70': x_build_rag_query__mutmut_70, 
    'x_build_rag_query__mutmut_71': x_build_rag_query__mutmut_71, 
    'x_build_rag_query__mutmut_72': x_build_rag_query__mutmut_72, 
    'x_build_rag_query__mutmut_73': x_build_rag_query__mutmut_73, 
    'x_build_rag_query__mutmut_74': x_build_rag_query__mutmut_74, 
    'x_build_rag_query__mutmut_75': x_build_rag_query__mutmut_75, 
    'x_build_rag_query__mutmut_76': x_build_rag_query__mutmut_76, 
    'x_build_rag_query__mutmut_77': x_build_rag_query__mutmut_77, 
    'x_build_rag_query__mutmut_78': x_build_rag_query__mutmut_78, 
    'x_build_rag_query__mutmut_79': x_build_rag_query__mutmut_79, 
    'x_build_rag_query__mutmut_80': x_build_rag_query__mutmut_80, 
    'x_build_rag_query__mutmut_81': x_build_rag_query__mutmut_81, 
    'x_build_rag_query__mutmut_82': x_build_rag_query__mutmut_82, 
    'x_build_rag_query__mutmut_83': x_build_rag_query__mutmut_83, 
    'x_build_rag_query__mutmut_84': x_build_rag_query__mutmut_84, 
    'x_build_rag_query__mutmut_85': x_build_rag_query__mutmut_85, 
    'x_build_rag_query__mutmut_86': x_build_rag_query__mutmut_86, 
    'x_build_rag_query__mutmut_87': x_build_rag_query__mutmut_87, 
    'x_build_rag_query__mutmut_88': x_build_rag_query__mutmut_88, 
    'x_build_rag_query__mutmut_89': x_build_rag_query__mutmut_89, 
    'x_build_rag_query__mutmut_90': x_build_rag_query__mutmut_90, 
    'x_build_rag_query__mutmut_91': x_build_rag_query__mutmut_91, 
    'x_build_rag_query__mutmut_92': x_build_rag_query__mutmut_92, 
    'x_build_rag_query__mutmut_93': x_build_rag_query__mutmut_93, 
    'x_build_rag_query__mutmut_94': x_build_rag_query__mutmut_94, 
    'x_build_rag_query__mutmut_95': x_build_rag_query__mutmut_95, 
    'x_build_rag_query__mutmut_96': x_build_rag_query__mutmut_96, 
    'x_build_rag_query__mutmut_97': x_build_rag_query__mutmut_97, 
    'x_build_rag_query__mutmut_98': x_build_rag_query__mutmut_98, 
    'x_build_rag_query__mutmut_99': x_build_rag_query__mutmut_99, 
    'x_build_rag_query__mutmut_100': x_build_rag_query__mutmut_100, 
    'x_build_rag_query__mutmut_101': x_build_rag_query__mutmut_101, 
    'x_build_rag_query__mutmut_102': x_build_rag_query__mutmut_102, 
    'x_build_rag_query__mutmut_103': x_build_rag_query__mutmut_103, 
    'x_build_rag_query__mutmut_104': x_build_rag_query__mutmut_104, 
    'x_build_rag_query__mutmut_105': x_build_rag_query__mutmut_105, 
    'x_build_rag_query__mutmut_106': x_build_rag_query__mutmut_106, 
    'x_build_rag_query__mutmut_107': x_build_rag_query__mutmut_107, 
    'x_build_rag_query__mutmut_108': x_build_rag_query__mutmut_108, 
    'x_build_rag_query__mutmut_109': x_build_rag_query__mutmut_109, 
    'x_build_rag_query__mutmut_110': x_build_rag_query__mutmut_110, 
    'x_build_rag_query__mutmut_111': x_build_rag_query__mutmut_111, 
    'x_build_rag_query__mutmut_112': x_build_rag_query__mutmut_112, 
    'x_build_rag_query__mutmut_113': x_build_rag_query__mutmut_113, 
    'x_build_rag_query__mutmut_114': x_build_rag_query__mutmut_114, 
    'x_build_rag_query__mutmut_115': x_build_rag_query__mutmut_115, 
    'x_build_rag_query__mutmut_116': x_build_rag_query__mutmut_116, 
    'x_build_rag_query__mutmut_117': x_build_rag_query__mutmut_117, 
    'x_build_rag_query__mutmut_118': x_build_rag_query__mutmut_118, 
    'x_build_rag_query__mutmut_119': x_build_rag_query__mutmut_119, 
    'x_build_rag_query__mutmut_120': x_build_rag_query__mutmut_120, 
    'x_build_rag_query__mutmut_121': x_build_rag_query__mutmut_121, 
    'x_build_rag_query__mutmut_122': x_build_rag_query__mutmut_122, 
    'x_build_rag_query__mutmut_123': x_build_rag_query__mutmut_123, 
    'x_build_rag_query__mutmut_124': x_build_rag_query__mutmut_124, 
    'x_build_rag_query__mutmut_125': x_build_rag_query__mutmut_125, 
    'x_build_rag_query__mutmut_126': x_build_rag_query__mutmut_126, 
    'x_build_rag_query__mutmut_127': x_build_rag_query__mutmut_127, 
    'x_build_rag_query__mutmut_128': x_build_rag_query__mutmut_128, 
    'x_build_rag_query__mutmut_129': x_build_rag_query__mutmut_129, 
    'x_build_rag_query__mutmut_130': x_build_rag_query__mutmut_130, 
    'x_build_rag_query__mutmut_131': x_build_rag_query__mutmut_131, 
    'x_build_rag_query__mutmut_132': x_build_rag_query__mutmut_132, 
    'x_build_rag_query__mutmut_133': x_build_rag_query__mutmut_133, 
    'x_build_rag_query__mutmut_134': x_build_rag_query__mutmut_134, 
    'x_build_rag_query__mutmut_135': x_build_rag_query__mutmut_135, 
    'x_build_rag_query__mutmut_136': x_build_rag_query__mutmut_136, 
    'x_build_rag_query__mutmut_137': x_build_rag_query__mutmut_137, 
    'x_build_rag_query__mutmut_138': x_build_rag_query__mutmut_138, 
    'x_build_rag_query__mutmut_139': x_build_rag_query__mutmut_139, 
    'x_build_rag_query__mutmut_140': x_build_rag_query__mutmut_140, 
    'x_build_rag_query__mutmut_141': x_build_rag_query__mutmut_141, 
    'x_build_rag_query__mutmut_142': x_build_rag_query__mutmut_142, 
    'x_build_rag_query__mutmut_143': x_build_rag_query__mutmut_143, 
    'x_build_rag_query__mutmut_144': x_build_rag_query__mutmut_144, 
    'x_build_rag_query__mutmut_145': x_build_rag_query__mutmut_145, 
    'x_build_rag_query__mutmut_146': x_build_rag_query__mutmut_146
}

def build_rag_query(*args, **kwargs):
    result = _mutmut_trampoline(x_build_rag_query__mutmut_orig, x_build_rag_query__mutmut_mutants, args, kwargs)
    return result 

build_rag_query.__signature__ = _mutmut_signature(x_build_rag_query__mutmut_orig)
x_build_rag_query__mutmut_orig.__name__ = 'x_build_rag_query'
