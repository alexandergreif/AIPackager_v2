"""Authentication and rate limiting middleware for API endpoints."""

import os
from functools import wraps
from typing import Optional

from dotenv import load_dotenv
from flask import jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from loguru import logger

# Load environment variables
load_dotenv()
from inspect import signature as _mutmut_signature
from typing import Annotated, Callable, ClassVar

MutantDict = Annotated[dict[str, Callable], "Mutant"]


def _mutmut_trampoline(orig, mutants, call_args, call_kwargs, self_arg=None):
    """Forward call to original or mutated function, depending on the environment"""
    import os

    mutant_under_test = os.environ["MUTANT_UNDER_TEST"]
    if mutant_under_test == "fail":
        from mutmut.__main__ import MutmutProgrammaticFailException

        raise MutmutProgrammaticFailException("Failed programmatically")
    elif mutant_under_test == "stats":
        from mutmut.__main__ import record_trampoline_hit

        record_trampoline_hit(orig.__module__ + "." + orig.__name__)
        result = orig(*call_args, **call_kwargs)
        return result  # for the yield case
    prefix = orig.__module__ + "." + orig.__name__ + "__mutmut_"
    if not mutant_under_test.startswith(prefix):
        result = orig(*call_args, **call_kwargs)
        return result  # for the yield case
    mutant_name = mutant_under_test.rpartition(".")[-1]
    if self_arg:
        # call to a class method where self is not bound
        result = mutants[mutant_name](self_arg, *call_args, **call_kwargs)
    else:
        result = mutants[mutant_name](*call_args, **call_kwargs)
    return result


from typing import Annotated, Callable

MutantDict = Annotated[dict[str, Callable], "Mutant"]


def _mutmut_yield_from_trampoline(orig, mutants, call_args, call_kwargs, self_arg=None):
    """Forward call to original or mutated function, depending on the environment"""
    import os

    mutant_under_test = os.environ["MUTANT_UNDER_TEST"]
    if mutant_under_test == "fail":
        from mutmut.__main__ import MutmutProgrammaticFailException

        raise MutmutProgrammaticFailException("Failed programmatically")
    elif mutant_under_test == "stats":
        from mutmut.__main__ import record_trampoline_hit

        record_trampoline_hit(orig.__module__ + "." + orig.__name__)
        result = yield from orig(*call_args, **call_kwargs)
        return result  # for the yield case
    prefix = orig.__module__ + "." + orig.__name__ + "__mutmut_"
    if not mutant_under_test.startswith(prefix):
        result = yield from orig(*call_args, **call_kwargs)
        return result  # for the yield case
    mutant_name = mutant_under_test.rpartition(".")[-1]
    if self_arg:
        # call to a class method where self is not bound
        result = yield from mutants[mutant_name](self_arg, *call_args, **call_kwargs)
    else:
        result = yield from mutants[mutant_name](*call_args, **call_kwargs)
    return result


def x_get_api_key__mutmut_orig() -> Optional[str]:
    """Get API key from environment variables.

    Returns:
        API key if configured, None otherwise
    """
    return os.getenv("API_KEY")


def x_get_api_key__mutmut_1() -> Optional[str]:
    """Get API key from environment variables.

    Returns:
        API key if configured, None otherwise
    """
    return os.getenv(None)


def x_get_api_key__mutmut_2() -> Optional[str]:
    """Get API key from environment variables.

    Returns:
        API key if configured, None otherwise
    """
    return os.getenv("XXAPI_KEYXX")


def x_get_api_key__mutmut_3() -> Optional[str]:
    """Get API key from environment variables.

    Returns:
        API key if configured, None otherwise
    """
    return os.getenv("api_key")


def x_get_api_key__mutmut_4() -> Optional[str]:
    """Get API key from environment variables.

    Returns:
        API key if configured, None otherwise
    """
    return os.getenv("Api_key")


x_get_api_key__mutmut_mutants: ClassVar[MutantDict] = {
    "x_get_api_key__mutmut_1": x_get_api_key__mutmut_1,
    "x_get_api_key__mutmut_2": x_get_api_key__mutmut_2,
    "x_get_api_key__mutmut_3": x_get_api_key__mutmut_3,
    "x_get_api_key__mutmut_4": x_get_api_key__mutmut_4,
}


def get_api_key(*args, **kwargs):
    result = _mutmut_trampoline(x_get_api_key__mutmut_orig, x_get_api_key__mutmut_mutants, args, kwargs)
    return result


get_api_key.__signature__ = _mutmut_signature(x_get_api_key__mutmut_orig)
x_get_api_key__mutmut_orig.__name__ = "x_get_api_key"


def require_api_key(f):
    """Decorator to require API key authentication.

    Args:
        f: Function to wrap

    Returns:
        Wrapped function
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Get configured API key
        configured_api_key = get_api_key()

        # If no API key is configured, allow access (for development)
        if not configured_api_key:
            logger.warning("No API key configured - allowing access")
            return f(*args, **kwargs)

        # Check for API key in headers
        provided_api_key = request.headers.get("X-API-Key") or request.headers.get("Authorization")

        # Handle Bearer token format
        if provided_api_key and provided_api_key.startswith("Bearer "):
            provided_api_key = provided_api_key[7:]  # Remove 'Bearer ' prefix

        if not provided_api_key:
            logger.warning(f"API key missing for {request.endpoint}")
            return jsonify(
                {
                    "error": "API key required",
                    "message": "Please provide API key in X-API-Key header or Authorization header",
                }
            ), 401

        if provided_api_key != configured_api_key:
            logger.warning(f"Invalid API key provided for {request.endpoint}")
            return jsonify(
                {
                    "error": "Invalid API key",
                    "message": "The provided API key is not valid",
                }
            ), 401

        logger.debug(f"API key validated for {request.endpoint}")
        return f(*args, **kwargs)

    return decorated_function


def x_init_limiter__mutmut_orig(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_1(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = None

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_2(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv(None, "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_3(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", None)

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_4(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_5(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv(
        "RATE_LIMIT_STORAGE_URI",
    )

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_6(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("XXRATE_LIMIT_STORAGE_URIXX", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_7(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("rate_limit_storage_uri", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_8(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("Rate_limit_storage_uri", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_9(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "XXmemory://XX")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_10(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "MEMORY://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_11(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "Memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_12(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = None

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_13(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=None,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_14(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=None,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_15(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=None,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_16(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=None,
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_17(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=None,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_18(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_19(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_20(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_21(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_22(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_23(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["XX1000 per dayXX", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_24(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 PER DAY", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_25(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "XX100 per hourXX"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_26(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 PER HOUR"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_27(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=False,
    )

    logger.info("Rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_28(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info(None)
    return limiter


def x_init_limiter__mutmut_29(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("XXRate limiting initializedXX")
    return limiter


def x_init_limiter__mutmut_30(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("rate limiting initialized")
    return limiter


def x_init_limiter__mutmut_31(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("RATE LIMITING INITIALIZED")
    return limiter


x_init_limiter__mutmut_mutants: ClassVar[MutantDict] = {
    "x_init_limiter__mutmut_1": x_init_limiter__mutmut_1,
    "x_init_limiter__mutmut_2": x_init_limiter__mutmut_2,
    "x_init_limiter__mutmut_3": x_init_limiter__mutmut_3,
    "x_init_limiter__mutmut_4": x_init_limiter__mutmut_4,
    "x_init_limiter__mutmut_5": x_init_limiter__mutmut_5,
    "x_init_limiter__mutmut_6": x_init_limiter__mutmut_6,
    "x_init_limiter__mutmut_7": x_init_limiter__mutmut_7,
    "x_init_limiter__mutmut_8": x_init_limiter__mutmut_8,
    "x_init_limiter__mutmut_9": x_init_limiter__mutmut_9,
    "x_init_limiter__mutmut_10": x_init_limiter__mutmut_10,
    "x_init_limiter__mutmut_11": x_init_limiter__mutmut_11,
    "x_init_limiter__mutmut_12": x_init_limiter__mutmut_12,
    "x_init_limiter__mutmut_13": x_init_limiter__mutmut_13,
    "x_init_limiter__mutmut_14": x_init_limiter__mutmut_14,
    "x_init_limiter__mutmut_15": x_init_limiter__mutmut_15,
    "x_init_limiter__mutmut_16": x_init_limiter__mutmut_16,
    "x_init_limiter__mutmut_17": x_init_limiter__mutmut_17,
    "x_init_limiter__mutmut_18": x_init_limiter__mutmut_18,
    "x_init_limiter__mutmut_19": x_init_limiter__mutmut_19,
    "x_init_limiter__mutmut_20": x_init_limiter__mutmut_20,
    "x_init_limiter__mutmut_21": x_init_limiter__mutmut_21,
    "x_init_limiter__mutmut_22": x_init_limiter__mutmut_22,
    "x_init_limiter__mutmut_23": x_init_limiter__mutmut_23,
    "x_init_limiter__mutmut_24": x_init_limiter__mutmut_24,
    "x_init_limiter__mutmut_25": x_init_limiter__mutmut_25,
    "x_init_limiter__mutmut_26": x_init_limiter__mutmut_26,
    "x_init_limiter__mutmut_27": x_init_limiter__mutmut_27,
    "x_init_limiter__mutmut_28": x_init_limiter__mutmut_28,
    "x_init_limiter__mutmut_29": x_init_limiter__mutmut_29,
    "x_init_limiter__mutmut_30": x_init_limiter__mutmut_30,
    "x_init_limiter__mutmut_31": x_init_limiter__mutmut_31,
}


def init_limiter(*args, **kwargs):
    result = _mutmut_trampoline(x_init_limiter__mutmut_orig, x_init_limiter__mutmut_mutants, args, kwargs)
    return result


init_limiter.__signature__ = _mutmut_signature(x_init_limiter__mutmut_orig)
x_init_limiter__mutmut_orig.__name__ = "x_init_limiter"


def apply_generation_rate_limit():
    """Apply rate limit for generation endpoints (100 req / 10 min per .clinerules).

    This is a decorator factory that returns the actual decorator.
    """

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Rate limiting is handled by Flask-Limiter decorators on routes
            return f(*args, **kwargs)

        return decorated_function

    return decorator


# Rate limit configurations
GENERATION_RATE_LIMIT = "100 per 10 minutes"
VALIDATION_RATE_LIMIT = "200 per 10 minutes"
SEARCH_RATE_LIMIT = "500 per 10 minutes"
