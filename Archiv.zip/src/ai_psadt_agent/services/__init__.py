"""Services module for business logic and AI integration."""
