import threading
import uuid
from typing import Callable

from loguru import logger

from ..domain_models.package import Package, StatusEnum
from ..infrastructure.db.session import get_db_session
from .prompt_templates import InstallerMetadata
from .script_generator import ScriptGenerator


def run_generation_in_background(package_id: str, app_context):
    """Runs the script generation in a background thread."""
    thread = threading.Thread(target=generate_and_update_package, args=(package_id, app_context))
    thread.daemon = True
    thread.start()


def generate_and_update_package(package_id: str, app):
    """The target function for the background thread."""
    with app.app_context():
        logger.info(f"Starting background generation for package_id: {package_id}")
        with get_db_session() as session:
            package = session.query(Package).filter(Package.package_id == uuid.UUID(package_id)).first()
            if not package:
                logger.error(f"Package with id {package_id} not found.")
                return

            package.status = StatusEnum.IN_PROGRESS
            session.commit()

            def progress_callback(progress: int, message: str):
                """Callback to update package progress in the database."""
                with get_db_session() as inner_session:
                    pkg_to_update = inner_session.query(Package).filter(Package.package_id == uuid.UUID(package_id)).first()
                    if pkg_to_update:
                        pkg_to_update.progress = progress
                        pkg_to_update.status_message = message
                        inner_session.commit()
                logger.debug(f"Progress for {package_id}: {progress}% - {message}")

            try:
                script_generator = ScriptGenerator()
                installer_metadata = InstallerMetadata(
                    name=package.name,
                    version=package.version or "0.0.0",
                    # These are placeholders, as we don't have this info yet
                    file_type=package.name.split('.')[-1] if package.name else "exe",
                    file_size=0,
                    architecture="x64",
                    language="en-US",
                    silent_switch="/S",
                )

                # We will modify generate_script to accept the callback
                result = script_generator.generate_script(
                    installer_metadata=installer_metadata,
                    user_notes=package.script_text,
                    progress_callback=progress_callback,
                )

                if result and result.structured_script:
                    package.script_text = result.script_content
                    package.status = StatusEnum.COMPLETED
                    package.progress = 100
                    package.status_message = "Completed"
                    logger.success(f"Successfully generated script for package {package_id}")
                else:
                    raise Exception("Script generation failed to produce a result.")

            except Exception as e:
                logger.error(f"Error during script generation for {package_id}: {e}")
                package.status = StatusEnum.FAILED
                package.status_message = f"Failed: {str(e)}"
            
            finally:
                session.add(package)
                session.commit()
