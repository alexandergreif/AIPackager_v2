"""Infrastructure package for database and other external services."""
