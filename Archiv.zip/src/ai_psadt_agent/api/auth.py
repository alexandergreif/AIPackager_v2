"""Authentication and rate limiting middleware for API endpoints."""

import os
from functools import wraps
from typing import Optional

from dotenv import load_dotenv
from flask import jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from loguru import logger

# Load environment variables
load_dotenv()


def get_api_key() -> Optional[str]:
    """Get API key from environment variables.

    Returns:
        API key if configured, None otherwise
    """
    return os.getenv("API_KEY")


def require_api_key(f):
    """Decorator to require API key authentication.

    Args:
        f: Function to wrap

    Returns:
        Wrapped function
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Get configured API key
        configured_api_key = get_api_key()

        # If no API key is configured, allow access (for development)
        if not configured_api_key:
            logger.warning("No API key configured - allowing access")
            return f(*args, **kwargs)

        # Check for API key in headers
        provided_api_key = request.headers.get("X-API-Key") or request.headers.get("Authorization")

        # Handle Bearer token format
        if provided_api_key and provided_api_key.startswith("Bearer "):
            provided_api_key = provided_api_key[7:]  # Remove 'Bearer ' prefix

        if not provided_api_key:
            logger.warning(f"API key missing for {request.endpoint}")
            return jsonify(
                {
                    "error": "API key required",
                    "message": "Please provide API key in X-API-Key header or Authorization header",
                }
            ), 401

        if provided_api_key != configured_api_key:
            logger.warning(f"Invalid API key provided for {request.endpoint}")
            return jsonify(
                {
                    "error": "Invalid API key",
                    "message": "The provided API key is not valid",
                }
            ), 401

        logger.debug(f"API key validated for {request.endpoint}")
        return f(*args, **kwargs)

    return decorated_function


def init_limiter(app):
    """Initialize Flask-Limiter for rate limiting.

    Args:
        app: Flask application instance

    Returns:
        Limiter instance
    """
    # Configure rate limiting storage
    storage_uri = os.getenv("RATE_LIMIT_STORAGE_URI", "memory://")

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        storage_uri=storage_uri,
        default_limits=["1000 per day", "100 per hour"],
        headers_enabled=True,
    )

    logger.info("Rate limiting initialized")
    return limiter


def apply_generation_rate_limit():
    """Apply rate limit for generation endpoints (100 req / 10 min per .clinerules).

    This is a decorator factory that returns the actual decorator.
    """

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Rate limiting is handled by Flask-Limiter decorators on routes
            return f(*args, **kwargs)

        return decorated_function

    return decorator


# Rate limit configurations
GENERATION_RATE_LIMIT = "100 per 10 minutes"
VALIDATION_RATE_LIMIT = "200 per 10 minutes"
SEARCH_RATE_LIMIT = "500 per 10 minutes"
